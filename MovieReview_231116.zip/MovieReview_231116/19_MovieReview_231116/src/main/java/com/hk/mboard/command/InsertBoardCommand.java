package com.hk.mboard.command;

import jakarta.validation.constraints.NotBlank;

public class InsertBoardCommand {
	
	
	private String name;
	private String genre_nm;
	
	@NotBlank(message = "영화 제목을 입력하세요")
	private String movie_nm;
	
	@NotBlank(message = "제목을 입력하세요")
	private String title;
	@NotBlank(message = "내용을 입력하세요")
	private String content;
	
	public InsertBoardCommand() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsertBoardCommand(String name, String genre_nm, @NotBlank(message = "영화 제목을 입력하세요") String movie_nm,
			@NotBlank(message = "제목을 입력하세요") String title, @NotBlank(message = "내용을 입력하세요") String content) {
		super();
		this.name = name;
		this.genre_nm = genre_nm;
		this.movie_nm = movie_nm;
		this.title = title;
		this.content = content;
	}

	@Override
	public String toString() {
		return "InsertBoardCommand [name=" + name + ", genre_nm=" + genre_nm + ", movie_nm=" + movie_nm + ", title="
				+ title + ", content=" + content + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGenre_nm() {
		return genre_nm;
	}

	public void setGenre_nm(String genre_nm) {
		this.genre_nm = genre_nm;
	}

	public String getMovie_nm() {
		return movie_nm;
	}

	public void setMovie_nm(String movie_nm) {
		this.movie_nm = movie_nm;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	
	
}
