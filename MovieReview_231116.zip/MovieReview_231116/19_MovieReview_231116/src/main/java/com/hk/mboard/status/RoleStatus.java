package com.hk.mboard.status;

public enum RoleStatus {
	ADMIN,USER
}
